<?php $view->script('driven.list', 'driven/listings:js/list.js', ['vue']) ?>
<driven-listing-container><slot></slot></driven-listing-container>